from flask import Flask, render_template, request, session, redirect, jsonify
import requests

app = Flask(__name__)
app.secret_key = "secret123"
DISCORD_API = "https://discord.com/api/v10"

def get_headers():
    return {"Authorization": f"Bot {session.get('token')}"}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['token'] = request.form['token']
        return redirect('/home')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/home')
def home():
    if not session.get('token'):
        return redirect('/')
    return render_template('home.html')

# API: Lấy guilds
@app.route('/api/guilds')
def get_guilds():
    r = requests.get(f"{DISCORD_API}/users/@me/guilds", headers=get_headers())
    return jsonify(r.json())

# API: Lấy channels trong guild
@app.route('/api/guilds/<guild_id>/channels')
def get_channels(guild_id):
    r = requests.get(f"{DISCORD_API}/guilds/{guild_id}/channels", headers=get_headers())
    return jsonify(r.json())

# API: Lấy tin nhắn trong channel
@app.route('/api/channels/<channel_id>/messages')
def get_messages(channel_id):
    r = requests.get(f"{DISCORD_API}/channels/{channel_id}/messages?limit=50", headers=get_headers())
    return jsonify(r.json())

# API: Gửi tin nhắn
@app.route('/api/channels/<channel_id>/messages', methods=['POST'])
def send_message(channel_id):
    data = request.json
    payload = {"content": data.get("content")}
    r = requests.post(f"{DISCORD_API}/channels/{channel_id}/messages",
                      headers={**get_headers(), "Content-Type": "application/json"},
                      json=payload)
    return jsonify(r.json()), r.status_code

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=10813, debug=True)