let selectedGuild = null;
let selectedChannel = null;

window.onload = () => {
    fetchGuilds();
};

function fetchGuilds() {
    fetch('/api/guilds')
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("guild-list");
            list.innerHTML = "";
            data.forEach(guild => {
                const li = document.createElement("li");
                li.textContent = guild.name;
                li.onclick = () => loadChannels(guild.id);
                list.appendChild(li);
            });
        });
}

function loadChannels(guildId) {
    selectedGuild = guildId;
    fetch(`/api/guilds/${guildId}/channels`)
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("channel-list");
            list.innerHTML = "";
            data.filter(c => c.type === 0).forEach(channel => {
                const li = document.createElement("li");
                li.textContent = `#${channel.name}`;
                li.onclick = () => loadMessages(channel.id);
                list.appendChild(li);
            });
        });
}

function loadMessages(channelId) {
    selectedChannel = channelId;
    fetch(`/api/channels/${channelId}/messages`)
        .then(res => res.json())
        .then(messages => {
            const box = document.getElementById("messages");
            box.innerHTML = "";
            messages.reverse().forEach(msg => {
                const div = document.createElement("div");
                div.innerHTML = `<strong>${msg.author.username}</strong>: ${msg.content}`;
                box.appendChild(div);
            });
        });
}

function sendMessage() {
    const input = document.getElementById("message-input");
    const content = input.value;
    if (!content || !selectedChannel) return;

    fetch(`/api/channels/${selectedChannel}/messages`, {
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({content})
    }).then(() => {
        input.value = "";
        loadMessages(selectedChannel);
    });
}